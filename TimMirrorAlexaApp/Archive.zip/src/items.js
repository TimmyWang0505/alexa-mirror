
var HOW_TO_LEARN_1 = 'This is the ',
    HOW_TO_LEARN_2 = ' learning path which is developed by Dalian';

module.exports = {
    'cyber security': 'For cyber security, currently the  yellow and green badge course are developed. You can take the training accordingly and get certificated. If you have any question you can contact Jerry Wang from PI QA team for support.',
    'cloud': 'For cloud development, currently the yellow and green badge course are developed. You can take the training accordingly and get certificated. If you have any questions you can contact Allen Shen for support.',
    'android': 'For android development, currently the yellow, green and purple badge course are developed. You can take the training accordingly and get certificated. If you have any questions you can contact Bill Mao for support.',
    'ios': 'For iOS development, currently the yellow, green and purple badge  course are developed. You can take the training accordingly and get certificated. If you have any questions you can contact Bill Mao for support.'
};